beta 4.1
4-17-23

ONLY PATCH ROMS THAT ARE (USA) OR (PRG0)
DO NOT PATCH ROMS THAT SAY (REV), GAME WILL NOT WORK PROPERLY/AT ALL

*changes
1: fixed world map color issues with red Toad (Tanoki/Hammer suits)
2: fixed twinkle toe effect, after jumping from slope that was ground pounded on
3: twinkle toe effect cancels out properly, when spamming A with Raccoon/Tanoki suits
4: can skip my custom intro, without one full viewing

There are two ips patches. Gameplay functions the same with each one, only difference 
is you can now decide what in-game color you want Toad to be in. Red, or blue.

	Super Mario Bros. 3 (b4.1_4-17-23_BT).ips [Blue Toad]
	Super Mario Bros. 3 (b4.1_4-17-23_RT).ips [Red Toad]

-infidelity
